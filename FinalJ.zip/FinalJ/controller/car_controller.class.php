<?php
/**
 * Author: Nicholas Weatherspoon/Paxton Darcy
 * Date: 12/4/2025
 * File: car_controller.class.php
 * Description: Controller class for the vehicles.
 */

// Controller class to manage vehicle-related actions
class CarsController {
    // Instance of the CarsModel (singleton)
    private CarsModel $carsModel;

    // Constructor initializes the CarsModel
    public function __construct() {
        $this->carsModel = CarsModel::getModel();
    }

    // Default method when no specific action is given
    public function index(): void {
        $this->listCars();
    }

    // Fetch and display all vehicles
    public function listCars() {
        try {
            // Get all vehicles from the model
            $vehicles = $this->carsModel->getCars();

            // Instantiate the view and display the vehicles
            $view = new VehicleView();
            $view->showAllVehicles($vehicles);
        } catch (Exception $e) {
            // Display error if something goes wrong
            echo "<p><strong>Error loading cars:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }

    // Fetch and display a single vehicle by ID
    public function listCarByID($id) {
        try {
            // Get vehicle details from the model
            $vehicle = $this->carsModel->getCarByID($id);

            // Instantiate the view and show details
            $view = new VehicleView();
            $view->showVehicleDetail($vehicle);
        } catch (Exception $e) {
            // Display error if something goes wrong
            echo "<p><strong>Error loading vehicle detail:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }

    // Search for vehicles based on a query string
    public function searchCars() {
        try {
            // Get search query from GET parameters
            $query = $_GET['query'] ?? '';

            // Fetch matching vehicles from model
            $results = $this->carsModel->searchCars($query);

            // Instantiate a search results view and display them
            $view = new carSearchResults();
            $view->display($results);
        } catch (Exception $e) {
            // Display error if something goes wrong
            echo "<p><strong>Error during search:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }

    // Delete a vehicle by ID (used for AJAX requests)
    public function deleteCar($id)
    {
        // Ensure the response is returned as JSON
        header('Content-Type: application/json');

        try {
            // Get the model instance
            $model = CarsModel::getModel();

            // Call the model method to delete the vehicle (must exist in CarsModel)
            $deleted = $model->deleteCarByID($id);

            // Return JSON success/failure response
            if ($deleted) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Could not delete vehicle']);
            }
        } catch (Exception $e) {
            // Return JSON with exception message
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }

        // Stop further PHP execution to prevent extra output
        exit;
    }

    // Add a new vehicle (handles POST submission)
    public function addCar(): void {
        try {
            // Only process POST requests
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $brand = $_POST['brand'] ?? '';
                $model = $_POST['model'] ?? '';
                $licensePlate = $_POST['licensePlate'] ?? '';
                $status = $_POST['status'] ?? 'Available';

                // Validate required fields
                if ($brand && $model && $licensePlate) {
                    // Insert vehicle into database
                    $this->carsModel->insertCar($brand, $model, $licensePlate, $status);

                    // Redirect to the list page after successful addition
                    header('Location: ' . BASE_URL . '/index.php/cars/listCars');
                    exit();
                } else {
                    $error = "Please fill in all required fields.";
                }
            }

            // Display the add vehicle form (with optional error message)
            $view = new addVehicle();
            $view->display($error ?? null);
        } catch (Exception $e) {
            // Display error if something goes wrong
            echo "<p><strong>Error adding vehicle:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }

    // Display the add vehicle form (GET request)
    public function addVehicleForm(): void {
        try {
            $view = new addVehicle();
            $view->display();
        } catch (Exception $e) {
            // Display error if form cannot be displayed
            echo "<p><strong>Error displaying add form:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }
}
?>
