<?php
/*
 * Author: Paxton Ducy
 * Date: 11/20/2025
 * Name: vehicle_view.class.php
 * Description: View layer for managing vehicles with Add/Delete functionality via AJAX.
 */

class VehicleView
{
    /** Display the search bar */
    public function showSearchBar(): void
    {
        echo '<form method="get" action="' . BASE_URL . '/index.php/cars/searchCars" style="margin-bottom:20px;">';
        echo '<input type="text" name="query" placeholder="Search vehicles..." required>';
        echo '<button type="submit">Search</button>';
        echo '</form>';
    }

    /** Display Add Vehicle and Delete Vehicles buttons only for logged-in users */
    public function addVehicle(): void
    {
        // Ensure session is active
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Only show buttons if user is logged in
        if (!empty($_SESSION['username'])) {
            // Add Vehicle button
            echo '<p>Sign in to Admin Account to Add/Delete a vehicle.</p>';
            echo '<p><a href="' . BASE_URL . '/index.php/cars/addVehicleForm">Add Vehicle</a></p>';



        }
    }

    /** Display logout button when logged in */
    public function logoutButton(): void
    {
        // Ensure session is active
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Only show logout when a user is logged in
        if (!empty($_SESSION['username'])) {
            echo '<p><a href="' . BASE_URL . '/index.php/users/logout">Logout</a></p>';
        }
    }

    /** Display all vehicles in a table with Delete buttons */
    public function showAllVehicles($vehicles)
    {
        // Ensure session is active
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Top section: search bar, add/delete buttons, logout
        echo '<div>';
        $this->showSearchBar();
        $this->addVehicle();
        $this->logoutButton();
        echo '</div>';

        // Table header
        echo "<h2>All Vehicles</h2>";
        echo "<table border='1' cellpadding='10'>";
        echo "<tr>
                <th>ID</th>
                <th>Brand</th>
                <th>Model</th>
                <th>License Plate</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>";

        // Loop through each vehicle
        foreach ($vehicles as $v) {
            $id = htmlspecialchars($v['id']);
            $brand = htmlspecialchars($v['brand']);
            $model = htmlspecialchars($v['model']);
            $plate = htmlspecialchars($v['licensePlate']);
            $status = htmlspecialchars($v['status']);

            echo "<tr id='vehicle-row-$id'>
                    <td>$id</td>
                    <td>$brand</td>
                    <td>$model</td>
                    <td>$plate</td>
                    <td>$status</td>
                    <td>
                        <a href='" . BASE_URL . "/index.php/cars/listCarByID/$id'>View</a>";

            // Only show delete button if logged in
            if (!empty($_SESSION['username'])) {
                echo " | <button class='delete-car-btn' data-id='$id'>Delete</button>";
            }

            echo "</td>
                 </tr>";
        }

        echo "</table>";

        // Inject AJAX script for Delete buttons
        $this->injectDeleteScript();
    }

    /** Inject JavaScript for AJAX vehicle deletion using XMLHttpRequest */
    private function injectDeleteScript(): void
    {
        echo "
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Attach click listeners to all delete buttons
                document.querySelectorAll('.delete-car-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const carId = this.dataset.id;

                        if (!confirm('Are you sure you want to delete this vehicle?')) return;

                        // Create XMLHttpRequest
                        const xhr = new XMLHttpRequest();
                        xhr.open('POST', '" . BASE_URL . "/index.php/cars/deleteCar/' + carId, true);
                        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

                        // Handle response
                        xhr.onload = function() {
                            if (xhr.status === 200) {
                                try {
                                    const response = JSON.parse(xhr.responseText);
                                    if (response.success) {
                                        // Remove the row from the table
                                        const row = document.getElementById('vehicle-row-' + carId);
                                        if (row) row.remove();
                                        alert('Vehicle deleted successfully.');
                                    } else {
                                        alert('Failed to delete vehicle: ' + (response.error || 'Unknown error'));
                                    }
                                } catch (e) {
                                    alert('Error parsing server response.');
                                }
                            } else {
                                alert('Request failed. Status: ' + xhr.status);
                            }
                        };

                        // Send request
                        xhr.send();
                    });
                });
            });
        </script>
        ";
    }

    /** Display detailed information for a single vehicle */
    public function showVehicleDetail($vehicle)
    {
        if (!$vehicle) {
            echo "<p>Vehicle not found.</p>";
            return;
        }

        echo "<h2>Vehicle Detail</h2><ul>";
        echo "<li><strong>ID:</strong> {$vehicle['id']}</li>";
        echo "<li><strong>Brand:</strong> {$vehicle['brand']}</li>";
        echo "<li><strong>Model:</strong> {$vehicle['model']}</li>";
        echo "<li><strong>License Plate:</strong> {$vehicle['licensePlate']}</li>";
        echo "<li><strong>Status:</strong> {$vehicle['status']}</li>";
        echo "</ul>";

        echo "<a href='" . BASE_URL . "/index.php/cars/listCars'>Back to list</a>";
    }
}
?>


