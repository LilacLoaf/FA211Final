//Author: Nicholas Weatherspoon


// Listen for any click events on the entire document
document.addEventListener("click", function(e) {
    // Check if the clicked element has the class "view-vehicle"
    if (e.target.classList.contains("view-vehicle")) {
        // Prevent the default link behavior (page reload/navigation)
        e.preventDefault();

        // Get the vehicle ID from the button/link data attribute
        let vehicleId = e.target.dataset.id;

        // Make an AJAX request using the Fetch API to get vehicle details
        fetch(`/FA211Final/Final/vehicleajax/get/${vehicleId}`)
            .then(response => {
                // Parse the response as JSON
                return response.json();
            })
            .then(data => {
                // Check if the server returned a successful result
                if (data.success) {
                    // Store the vehicle object from the response
                    let v = data.vehicle;

                    // Insert the vehicle details into the HTML container
                    document.getElementById("vehicle-details").innerHTML = `
                        <h3>Vehicle Details (Loaded with AJAX)</h3>
                        <ul>
                            <li><strong>ID:</strong> ${v.id}</li>
                            <li><strong>Brand:</strong> ${v.brand}</li>
                            <li><strong>Model:</strong> ${v.model}</li>
                            <li><strong>License Plate:</strong> ${v.licensePlate}</li>
                            <li><strong>Status:</strong> ${v.status}</li>
                        </ul>
                    `;
                } else {
                    // If the vehicle is not found, show an error message
                    document.getElementById("vehicle-details").innerHTML =
                        "<p>Vehicle not found.</p>";
                }
            })
            .catch(error => {
                // Handle network or parsing errors
                console.error("Error fetching vehicle details:", error);
                document.getElementById("vehicle-details").innerHTML =
                    "<p>There was an error loading vehicle details.</p>";
            });
    }
});

