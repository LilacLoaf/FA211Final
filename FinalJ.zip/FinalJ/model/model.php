<?php
/**
 * Author: Jonathan Nguyen
 * Date: 12/4/2025
 * File: model.php
 * Description: Cars Model (Singleton) - Works with Database Singleton
 */

class CarsModel {

    private Database $db;      // Database singleton
    private mysqli $conn;      // MySQL connection
    private static ?CarsModel $_instance = null;

    // Fixed table name for vehicles
    private string $tblVehicles = 'vehicles';


     // Private constructor for singleton pattern
     // Initializes DB connection and escapes POST/GET data

    private function __construct() {
        try {
            $this->db = Database::getDatabase();
            $this->conn = $this->db->getConnection();

            // Escape POST data to prevent SQL injection
            foreach ($_POST as $key => $value) {
                $_POST[$key] = $this->conn->real_escape_string($value);
            }

            // Escape GET data to prevent SQL injection
            foreach ($_GET as $key => $value) {
                $_GET[$key] = $this->conn->real_escape_string($value);
            }
        } catch (Exception $e) {
            echo "<p><strong>Error initializing CarsModel:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }


     // Get the singleton instance

    public static function getModel(): CarsModel {
        if (self::$_instance === null) {
            self::$_instance = new CarsModel();
        }
        return self::$_instance;
    }


    // Retrieve all vehicles

    public function getCars(): array|false {
        try {
            $sql = "SELECT * FROM $this->tblVehicles";
            $result = $this->conn->query($sql);

            if (!$result) return false;

            $vehicles = [];
            while ($row = $result->fetch_assoc()) {
                $vehicles[] = $row;
            }
            return $vehicles;
        } catch (Exception $e) {
            echo "<p><strong>Error fetching cars:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
            return false;
        }
    }


     // Retrieve a vehicle by ID

    public function getCarByID($id): array|false {
        try {
            $sql = "SELECT * FROM $this->tblVehicles WHERE id='$id' LIMIT 1";
            $result = $this->conn->query($sql);

            return ($result && $result->num_rows > 0) ? $result->fetch_assoc() : false;
        } catch (Exception $e) {
            echo "<p><strong>Error fetching car by ID:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
            return false;
        }
    }

     // Search vehicles by query string

    public function searchCars(string $query, string $mode = 'AND'): array {
        try {
            $keywords = array_filter(explode(" ", trim($query)));
            if (empty($keywords)) return [];

            $connector = strtoupper($mode) === 'OR' ? 'OR' : 'AND';

            $where = array_map(function ($word) {
                $word = $this->conn->real_escape_string($word);
                return "(brand LIKE '%$word%' OR model LIKE '%$word%' OR licensePlate LIKE '%$word%')";
            }, $keywords);

            $sql = "SELECT * FROM $this->tblVehicles WHERE " . implode(" $connector ", $where);
            $result = $this->conn->query($sql);

            return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
        } catch (Exception $e) {
            echo "<p><strong>Error searching cars:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
            return [];
        }
    }


    //Insert a new vehicle

    public function insertCar(string $brand, string $model, string $licensePlate, string $status = 'Available'): bool {
        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO $this->tblVehicles (brand, model, licensePlate, status) VALUES (?, ?, ?, ?)"
            );
            $stmt->bind_param("ssss", $brand, $model, $licensePlate, $status);
            return $stmt->execute();
        } catch (Exception $e) {
            echo "<p><strong>Error inserting car:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
            return false;
        }
    }

     // Delete a vehicle by ID

    public function deleteCarByID(string $id): bool {
        // Check if any rentals reference this vehicle
        $check = $this->conn->prepare("SELECT COUNT(*) as cnt FROM rentedcars WHERE vehicle = ?");
        $check->bind_param("s", $id);
        $check->execute();
        $result = $check->get_result()->fetch_assoc();

        if ($result['cnt'] > 0) {
            // Cannot delete because vehicle is rented
            return false;
        }

        // Safe to delete
        $stmt = $this->conn->prepare("DELETE FROM vehicles WHERE id = ?");
        $stmt->bind_param("s", $id);
        return $stmt->execute();
    }


}
